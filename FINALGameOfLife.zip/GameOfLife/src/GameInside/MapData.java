package GameInside;

public interface MapData {
    int[][] map = new int[1000][1000];
    Map mapSpace = new Map(10, 10);
    int coordinates[][] = new int[1000][1000];

}
