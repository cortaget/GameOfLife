import GameInside.Game;
import GameInside.MapData;



public class Main implements MapData {
    public static void main(String[] args) {
        Game game = new Game();
        game.press();




    }
}
